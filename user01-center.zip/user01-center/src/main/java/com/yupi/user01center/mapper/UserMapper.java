package com.yupi.user01center.mapper;

import com.yupi.user01center.moudel.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity generator.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




