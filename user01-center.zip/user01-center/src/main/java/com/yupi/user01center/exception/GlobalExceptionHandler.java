package com.yupi.user01center.exception;

import com.yupi.user01center.common.BaseResponse;
import com.yupi.user01center.common.ErrorCode;
import com.yupi.user01center.common.ResultUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理器
 * （Spring AOP 在调用方法前后进行额外的处理）
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    //此方法只捕获这个异常
    @ExceptionHandler(BusinessException.class)
    public BaseResponse businessExceptionHandler(BusinessException e){
        log.error("businessException: " + e.getMessage(), e);
        return ResultUtils.error(e.getCode(), e.getMessage(), e.getDescription());
    }
    @ExceptionHandler(RuntimeException.class)
    public BaseResponse runTimeExceptionHandler(RuntimeException e){
        log.error("runTimeException", e);
        return ResultUtils.error(ErrorCode.SYSTEM_ERROR, e.getMessage(), "");
    }
}
