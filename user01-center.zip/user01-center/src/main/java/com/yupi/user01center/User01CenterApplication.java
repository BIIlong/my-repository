package com.yupi.user01center;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.yupi.user01center.mapper")
public class User01CenterApplication {

    public static void main(String[] args) {

        SpringApplication.run(User01CenterApplication.class, args);
    }

}
