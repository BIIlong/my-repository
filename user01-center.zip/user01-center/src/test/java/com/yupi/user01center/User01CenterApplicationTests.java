package com.yupi.user01center;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootTest
class User01CenterApplicationTests {

    @Test
    void testDigest() throws NoSuchAlgorithmException {
        String newpassword = DigestUtils.md5DigestAsHex(("abcd" + "mypassword").getBytes());
        System.out.println(newpassword);
    }

    @Test
    void contextLoads() {
    }

}
